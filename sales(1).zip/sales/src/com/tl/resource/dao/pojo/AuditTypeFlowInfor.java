package com.tl.resource.dao.pojo;

public class AuditTypeFlowInfor {
	private String auditTypeId;
	private String auditTypeName;
	private String auditFlowId;
	private String auditFlowName;
	private String departId;
	private String departName;
	private Integer count;
	public String getAuditTypeId() {
		return auditTypeId;
	}
	public void setAuditTypeId(String auditTypeId) {
		this.auditTypeId = auditTypeId;
	}
	public String getAuditTypeName() {
		return auditTypeName;
	}
	public void setAuditTypeName(String auditTypeName) {
		this.auditTypeName = auditTypeName;
	}
	public String getAuditFlowId() {
		return auditFlowId;
	}
	public void setAuditFlowId(String auditFlowId) {
		this.auditFlowId = auditFlowId;
	}
	public String getAuditFlowName() {
		return auditFlowName;
	}
	public void setAuditFlowName(String auditFlowName) {
		this.auditFlowName = auditFlowName;
	}
	public String getDepartId() {
		return departId;
	}
	public void setDepartId(String departId) {
		this.departId = departId;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	
}
