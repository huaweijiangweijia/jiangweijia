package com.tl.resource.dao.pojo;

import java.util.Date;

public class SystemRun {

	
	private int id;
	
	private Date startTime ; //系统开始运行时间
	
	private Date lastResetTime ;  //最后重置单据流水时间

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getLastResetTime() {
		return lastResetTime;
	}

	public void setLastResetTime(Date lastResetTime) {
		this.lastResetTime = lastResetTime;
	}
	
	
}
