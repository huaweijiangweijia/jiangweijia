package com.tl.resource.dao.constant;

/**
 * 用户信息
 * @author lichicheng
 *
 */
public class TUserInforConstant {
	public static final String KEY = "TUserInforConstant.";
	public static final String USER_ID = KEY + "user_id";
	public static final String USER_ID_LIST = KEY +  "user_ids";
}
