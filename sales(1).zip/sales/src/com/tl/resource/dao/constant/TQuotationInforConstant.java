package com.tl.resource.dao.constant;

public class TQuotationInforConstant {

	public static final String KEY = "TQuotationInforConstant.";

	public static final String QUOTATION_CODE = KEY + "quotationCode";
	public static final String QUOTATION_CODE_LIKE = KEY + "quotationCodeLike";
	public static final String CUSTOMER_NAME_LIKE = KEY + "customerName";

	public static final String EDIT_DATE_GT_EQ = KEY + "editDateGtEq";
	
	public static final String EDIT_DATE_LT_EQ = KEY + "editDateLtEq";
	
	public static final String QUOTATION_TYPE = KEY + "quotationType";
	public static final String STATUS = KEY + "STATUS";

	public static final String USER_NAME_LIKE = KEY + "userNameLike";
	public static final String EDITOR_NAME_LIKE = KEY + "editorNameLike";
	
}
