package com.tl.resource.dao.constant;

public class TOrderInforConstant {
	public final static String KEY = "TOrderInforConstant.";
	public final static String ORDER_TYPE=KEY+"orderType";
}
