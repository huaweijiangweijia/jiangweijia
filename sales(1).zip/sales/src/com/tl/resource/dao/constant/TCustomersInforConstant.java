package com.tl.resource.dao.constant;

public class TCustomersInforConstant {
	public static final String KEY = "TCustomersInforConstant.";
	public static final String CUSTOMER_NAME_LIKE = "customerNameLike";
}
