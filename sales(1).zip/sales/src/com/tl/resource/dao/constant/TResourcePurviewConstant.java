package com.tl.resource.dao.constant;

/**
 * 数据查看权限
 * @author lichicheng
 *
 */
public class TResourcePurviewConstant {
	public static final String KEY = "TResourcePurviewConstant.";
	public static final String RESOURCE_TYPE  = KEY + "resource_type";
	public static final String USER_ID= KEY + "user_id";
}
