package com.tl.resource.dao.constant;

/**
 * 产品信息
 * @author lichicheng
 *
 */
public class TProductToolsInforConstant {
	public static final String KEY = "TProductToolsInforConstant.";
	
	public static final String LEAF = KEY + "leaf";//

	public static final String PARENT_ID = KEY +"parentId";
}
