package com.tl.resource.business.dto;

import java.math.BigDecimal;

public class ReserveInforDto {
	
	private String id;
	
	private String productCode;
	
	private String brandCode;
	
	private String toolsId;
	
	private String parentToolsId;
	
	private Integer leaf;
	
	private String productName;
	
	private String productUnit;
	
	private String reserveCode;
	
	private BigDecimal amount;
	
	private BigDecimal price;
	
	private String productSort;
	
	private String currencyName;
	
	private String productBrand;
	
	private String productSource;
	
	private String productPosition;
	
	private String slaveFile;
	
	private String memo;
	private BigDecimal dtAmount;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getBrandCode() {
		return brandCode;
	}

	public void setBrandCode(String brandCode) {
		this.brandCode = brandCode;
	}

	public String getToolsId() {
		return toolsId;
	}

	public void setToolsId(String toolsId) {
		this.toolsId = toolsId;
	}

	public String getParentToolsId() {
		return parentToolsId;
	}

	public void setParentToolsId(String parentToolsId) {
		this.parentToolsId = parentToolsId;
	}

	public Integer getLeaf() {
		return leaf;
	}

	public void setLeaf(Integer leaf) {
		this.leaf = leaf;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductUnit() {
		return productUnit;
	}

	public void setProductUnit(String productUnit) {
		this.productUnit = productUnit;
	}

	public String getReserveCode() {
		return reserveCode;
	}

	public void setReserveCode(String reserveCode) {
		this.reserveCode = reserveCode;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getProductSort() {
		return productSort;
	}

	public void setProductSort(String productSort) {
		this.productSort = productSort;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public String getProductSource() {
		return productSource;
	}

	public void setProductSource(String productSource) {
		this.productSource = productSource;
	}

	public String getProductPosition() {
		return productPosition;
	}

	public void setProductPosition(String productPosition) {
		this.productPosition = productPosition;
	}

	public String getSlaveFile() {
		return slaveFile;
	}

	public void setSlaveFile(String slaveFile) {
		this.slaveFile = slaveFile;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public BigDecimal getDtAmount() {
		return dtAmount;
	}

	public void setDtAmount(BigDecimal dtAmount) {
		this.dtAmount = dtAmount;
	}
	
	
}
