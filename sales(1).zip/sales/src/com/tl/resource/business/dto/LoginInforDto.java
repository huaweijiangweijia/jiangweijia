package com.tl.resource.business.dto;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.tl.resource.dao.pojo.TContractInfor;

public class LoginInforDto {
	private UserDto user = null;
	private List<ModulesDto> modules = null;
	private String ip = null;
	private Long lastRead = System.currentTimeMillis();
	private HttpSession session;
	private List<TContractInfor> contractInfors;
	
	public List<TContractInfor> getContractInfors() {
		return contractInfors;
	}
	public void setContractInfors(List<TContractInfor> contractInfors) {
		this.contractInfors = contractInfors;
	}
	public UserDto getUser() {
		return user;
	}
	public void setUser(UserDto user) {
		this.user = user;
	}
	public List<ModulesDto> getModules() {
		return modules;
	}
	public void setModules(List<ModulesDto> modules) {
		this.modules = modules;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Long getLastRead() {
		return lastRead;
	}
	public void setLastRead(Long lastRead) {
		this.lastRead = lastRead;
	}
	public HttpSession getSession() {
		return session;
	}
	public void setSession(HttpSession session) {
		this.session = session;
	}
	
	
}
