package com.tl.resource.business.dto;


public class SuppliersInforDto {

	
	private String id;
	
	private String supplierCode;
	
	private String supplierName;
	
	private String supplierShortName;
	
	private String contactPersonFirst;
	
	private String phoneFirst;
	
	private String faxFirst;
	
	private String contactPersonSec;
	
	private String phoneSec;
	
	private String faxSec;
	
	private String brandFirst;
	
	private String brandSec;
	
	private String brandThird;
	
	private String brandFourth;
	
	private String contractAddress;
	
	private String postcode;
	
	private String comAdress;
	
	private String bank;
	
	private String accountNumber;
	
	private String homePage;
	
	private String email;
	
	private String memo;
	
	private String taxCode;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public String getSupplierShortName() {
		return supplierShortName;
	}

	public void setSupplierShortName(String supplierShortName) {
		this.supplierShortName = supplierShortName;
	}

	public String getContactPersonFirst() {
		return contactPersonFirst;
	}

	public void setContactPersonFirst(String contactPersonFirst) {
		this.contactPersonFirst = contactPersonFirst;
	}

	public String getPhoneFirst() {
		return phoneFirst;
	}

	public void setPhoneFirst(String phoneFirst) {
		this.phoneFirst = phoneFirst;
	}

	public String getFaxFirst() {
		return faxFirst;
	}

	public void setFaxFirst(String faxFirst) {
		this.faxFirst = faxFirst;
	}

	public String getContactPersonSec() {
		return contactPersonSec;
	}

	public void setContactPersonSec(String contactPersonSec) {
		this.contactPersonSec = contactPersonSec;
	}

	public String getPhoneSec() {
		return phoneSec;
	}

	public void setPhoneSec(String phoneSec) {
		this.phoneSec = phoneSec;
	}

	public String getFaxSec() {
		return faxSec;
	}

	public void setFaxSec(String faxSec) {
		this.faxSec = faxSec;
	}

	public String getBrandFirst() {
		return brandFirst;
	}

	public void setBrandFirst(String brandFirst) {
		this.brandFirst = brandFirst;
	}

	public String getBrandSec() {
		return brandSec;
	}

	public void setBrandSec(String brandSec) {
		this.brandSec = brandSec;
	}

	public String getBrandThird() {
		return brandThird;
	}

	public void setBrandThird(String brandThird) {
		this.brandThird = brandThird;
	}

	public String getBrandFourth() {
		return brandFourth;
	}

	public void setBrandFourth(String brandFourth) {
		this.brandFourth = brandFourth;
	}

	public String getContractAddress() {
		return contractAddress;
	}

	public void setContractAddress(String contractAddress) {
		this.contractAddress = contractAddress;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getComAdress() {
		return comAdress;
	}

	public void setComAdress(String comAdress) {
		this.comAdress = comAdress;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getHomePage() {
		return homePage;
	}

	public void setHomePage(String homePage) {
		this.homePage = homePage;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getTaxCode() {
		return taxCode;
	}

	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	
	}