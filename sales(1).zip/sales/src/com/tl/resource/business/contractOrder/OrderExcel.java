package com.tl.resource.business.contractOrder;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface OrderExcel {
	public void exportExcel(String conId,HttpServletResponse response, HttpServletRequest request)throws IOException;
	
	public void orderListExcel(Map<String, Object> parmMap,HttpServletResponse response, HttpServletRequest request)throws IOException;;
}
