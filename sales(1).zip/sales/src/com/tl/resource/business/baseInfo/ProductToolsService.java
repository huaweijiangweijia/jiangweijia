package com.tl.resource.business.baseInfo;

import java.util.List;
import java.util.Map;

import com.tl.common.util.PaginationSupport;
import com.tl.resource.business.dto.TreeDto;

public interface ProductToolsService {
	PaginationSupport getProductToolsList(Map<String, Object> parmMap,int startIndex,int pageSize);
	
	void updateProductOrderPriceInfor(List<TreeDto> toolsDto);
	
	void updateProductSalesPriceInfor(List<TreeDto> toolsDto);
}
