package com.tl.resource.business.assessment;

import java.util.Map;

import com.tl.common.util.PaginationSupport;
import com.tl.resource.dao.pojo.TSupplierAssessment;

public interface SupplierAssessmentService {

	
	public void addSupplierAssessment(TSupplierAssessment obj);
	
	public void updateSupplierAssessment(TSupplierAssessment obj);
	
	public void deleteSupplierAssessment(String id);
	
	public PaginationSupport findSupplierAssessmentList(Map<String,Object> params,int startIndex,int pageSize);
	
	
	
}
