package com.tl.resource.business.assessment;

import java.util.Map;

import com.tl.common.util.PaginationSupport;
import com.tl.resource.dao.pojo.TCustormerAssessment;

public interface CustormerAssessmentService {

	
	public void addCustormerAssessment(TCustormerAssessment obj);
	
	public void updateCustormerAssessment(TCustormerAssessment obj);
	
	public void deleteCustormerAssessment(String id);
	
	public PaginationSupport findCustormerAssessmentList(Map<String,Object> params,int startIndex,int pageSize);
	
	
	
}
