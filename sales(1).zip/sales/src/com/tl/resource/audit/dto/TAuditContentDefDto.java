package com.tl.resource.audit.dto;

public class TAuditContentDefDto {
	private String id;
    private String auditContentName;
    private String memo;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAuditContentName() {
		return auditContentName;
	}
	public void setAuditContentName(String auditContentName) {
		this.auditContentName = auditContentName;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
    
}
