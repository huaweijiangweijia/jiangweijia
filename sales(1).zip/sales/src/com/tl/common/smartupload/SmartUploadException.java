// Decompiled by Jad v1.5.7g. Copyright 2000 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   SmartUploadException.java

package com.tl.common.smartupload;


public class SmartUploadException extends Exception
{

    SmartUploadException(String desc)
    {
        super(desc);
    }
}
