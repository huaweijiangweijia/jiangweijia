package com.tl.common.action;

import org.apache.struts.actions.DispatchAction;

public abstract class BaseAction extends DispatchAction {
 
}