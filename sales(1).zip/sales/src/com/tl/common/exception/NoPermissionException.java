package com.tl.common.exception;

@SuppressWarnings("serial")
public class NoPermissionException extends ApplicationException {

	public NoPermissionException(String msg) {
		super(msg);
	}

}
