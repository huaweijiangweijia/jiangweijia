package com.tl.common.exception;

public class ErrorCode {
	// 系统管理错误前缀 10
	public static String SYS_ERR = "10";

	// 资源管理系统错误前缀 20
	public static String RES_SYS_ERR = "20";

	// --------------系统管理明细-------------------
	public static String SYS_LOGIN_FAIL = SYS_ERR + "0001";

	// --------------资源管理系统明细---------------------

}
