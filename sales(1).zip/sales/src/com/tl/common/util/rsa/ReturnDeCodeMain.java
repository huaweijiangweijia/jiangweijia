package com.tl.common.util.rsa;

import com.tl.common.util.RsaUtil;

public class ReturnDeCodeMain {
	public static void main(String[] args) {
		RsaUtil ru = new RsaUtil();
		String sn = args[0];
		//System.out.println(ru.decryptStringENC(sn));
	}
}
